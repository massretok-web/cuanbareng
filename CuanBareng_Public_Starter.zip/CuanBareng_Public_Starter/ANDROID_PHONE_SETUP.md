# Memulai CuanBareng dari HP Android

## Tahap 1 — Uji lokal
1. Ekstrak `CuanBareng_Public_Starter.zip`.
2. Buka `index.html` dengan Chrome atau browser yang tersedia.
3. Coba menu Katalog, Tambah, Bagikan tautan, dan Info.
4. Ini hanya demo; produk baru tidak otomatis muncul di HP pengguna lain.

## Tahap 2 — Jadikan PWA online gratis
1. Dari browser HP, masuk ke GitHub dan buat repository baru `cuanbareng`.
2. Unggah semua file dalam folder paket ke root repository.
3. Buka Settings → Pages.
4. Di bagian Build and deployment, pilih deploy from branch, branch `main`, folder `/(root)`, lalu Save.
5. Tunggu URL HTTPS GitHub Pages.
6. Buka URL itu di Chrome Android → menu ⋮ → Tambahkan ke layar utama / Install app.

Label menu dapat sedikit berbeda menurut versi Chrome/GitHub. Hosting statis bukan database bersama.

## Tahap 3 — Sebelum menerima publik
- Buat backend dan autentikasi.
- Sambungkan frontend ke database dengan kebijakan akses yang diuji.
- Tentukan apakah tautan produk pribadi atau dipublikasikan ke katalog umum.
- Tambahkan moderasi, laporan spam, pembatasan laju, hapus akun, kebijakan privasi, dan kontak dukungan.
- Uji akses antar pengguna: pengguna A tidak boleh mengubah atau membaca data privat pengguna B.
- Jangan memasukkan service-role key atau token TikTok di frontend.

## Tahap 4 — APK Android
PWA dapat dipasang melalui browser tanpa APK. APK native biasanya membutuhkan toolchain Android build. Dari HP saja, jalur yang mungkin adalah layanan build berbasis cloud/CI, tetapi perlu konfigurasi proyek dan penandatanganan yang aman. Jangan membagikan keystore atau kata sandinya kepada siapa pun. APK belum disertakan dalam paket ini.
