# Draf kebijakan privasi & ketentuan CuanBareng

> DRAF SAJA — jangan dipublikasikan sebelum identitas pengelola, kontak, praktik data sebenarnya, dan persyaratan hukum ditinjau.

## Kebijakan privasi (draf)
CuanBareng membantu pengguna mengatur dan membagikan tautan promosi affiliate. Pada versi demo saat ini, aplikasi tidak menyediakan akun dan tidak mengirim katalog ke server. Data yang ditambahkan hanya berada di sesi halaman dan dapat hilang saat halaman ditutup.

Sebelum versi publik diluncurkan, pengelola harus menjelaskan secara akurat:
- data apa yang dikumpulkan (misalnya email, nama tampilan, tautan produk, log teknis);
- tujuan dan dasar pemrosesan;
- penyedia layanan pihak ketiga yang digunakan;
- masa penyimpanan dan cara meminta akses, koreksi, atau penghapusan;
- kontak pengelola dan prosedur penanganan insiden;
- apakah data dipindahkan atau diproses di luar Indonesia.

Jangan mengumpulkan data yang tidak diperlukan. Jangan meminta kata sandi TikTok, OTP, atau kredensial pembayaran. Terapkan kontrol akses, RLS, HTTPS, pembatasan permintaan, dan proses penghapusan akun sebelum rilis publik.

## Ketentuan layanan (draf)
CuanBareng adalah alat bantu independen untuk mengelola tautan promosi dan bukan aplikasi resmi TikTok/TikTok Shop. Nama dan merek TikTok dimiliki pemiliknya masing-masing. Ketersediaan produk, harga, syarat komisi, validitas transaksi, dan pembayaran ditentukan oleh platform dan/atau penjual yang bersangkutan.

Tidak ada jaminan pendapatan. Pengguna harus memakai tautan resmi miliknya, mengungkapkan hubungan affiliate secara wajar, mematuhi aturan platform dan hukum yang berlaku, serta tidak melakukan spam, penipuan, atau klaim yang menyesatkan.

Pengelola perlu menambahkan prosedur pelaporan konten/tautan, moderasi, pembekuan akun yang melanggar, pembaruan ketentuan, serta kontak bantuan sebelum menerima pengguna publik.
