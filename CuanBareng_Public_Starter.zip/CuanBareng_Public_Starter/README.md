# CuanBareng — Public Starter Kit (Android-first)

## Isi paket
- `index.html` — prototype responsif berbahasa Indonesia.
- `manifest.webmanifest` — metadata agar browser mendukung instalasi PWA.
- `sw.js` — cache offline dasar.
- `supabase_schema.sql` — skema database awal dengan Row Level Security (belum dihubungkan ke frontend).
- `PRIVACY_TERMS_DRAFT.md` — draf awal kebijakan dan ketentuan yang harus disesuaikan.
- `ANDROID_PHONE_SETUP.md` — langkah mulai dari HP Android.

## Penting: status saat ini
Ini **starter/demo**, bukan aplikasi publik siap produksi dan bukan APK. Fitur saat ini:
- Katalog contoh.
- Tambah tautan HTTPS manual.
- Bagikan tautan menggunakan fitur browser.
- Catatan aktivitas selama sesi halaman.
- Manifest PWA dan cache dasar.

Belum tersedia:
- Login/registrasi nyata.
- Database bersama yang terhubung.
- Katalog publik antar pengguna.
- Admin/moderasi, pelaporan spam, penghapusan akun.
- Integrasi API TikTok Shop, tracking order, saldo, komisi terverifikasi, atau pembayaran.

Jangan promosikan demo ini seolah-olah memiliki pelacakan komisi otomatis.

## Jalur yang realistis tanpa laptop
1. Ekstrak ZIP di HP memakai aplikasi pengelola berkas.
2. Buka `index.html` untuk uji tampilan lokal. Fitur PWA/install biasanya membutuhkan HTTPS hosting.
3. Buat akun GitHub jika belum punya, lalu buat repository baru bernama `cuanbareng`.
4. Unggah file proyek ke repository lewat browser HP.
5. Di repository GitHub, buka Settings → Pages, pilih deploy dari branch utama dan folder root, lalu simpan. Tunggu alamat Pages diberikan GitHub.
6. Buka alamat HTTPS tersebut di Chrome Android. Dari menu Chrome, pilih **Tambahkan ke layar utama** atau **Install app** bila tersedia.
7. Sebelum mengundang publik, sambungkan autentikasi/database, uji keamanan, tambahkan mekanisme laporan dan penghapusan data, serta terbitkan kebijakan privasi yang benar.

GitHub Pages hanya meng-host frontend statis. Ia tidak menggantikan backend atau database dan tidak boleh menyimpan rahasia API.

## Database
`supabase_schema.sql` adalah fondasi awal untuk Supabase, belum terhubung dengan aplikasi. Buat proyek Supabase sendiri, baca SQL-nya, lalu jalankan melalui SQL Editor setelah memahami kebijakannya. Jangan membagikan kata sandi, kode OTP, atau service-role key di chat. Kunci service-role tidak boleh ada di frontend.

## TikTok Shop
Gunakan tautan affiliate yang dibuat melalui fitur resmi akun TikTok Shop. Kelayakan dan fitur bisa berbeda menurut akun/negara dan dapat berubah. Komisi resmi hanya dapat diverifikasi di sistem TikTok Shop.
- https://business.tiktokshop.com/id/affiliate
- https://partner.tiktokshop.com/docv2/page/affiliate-integration
- https://partner.tiktokshop.com/docv2/page/678e3a362dccb8030ea6f98c

Integrasi API resmi membutuhkan persetujuan akses dan alur otorisasi yang sesuai. Jangan memasukkan token atau app secret ke browser atau APK.

## Monetisasi yang jujur
- Pengguna dapat memperoleh komisi dari penjualan yang memenuhi ketentuan program affiliate.
- CuanBareng tidak otomatis memperoleh bagian dari komisi kreator.
- Monetisasi platform perlu jalur yang diizinkan (misalnya iklan atau layanan premium setelah siap) dan harus dijelaskan kepada pengguna.
- Jangan menjanjikan penghasilan atau menampilkan angka demo sebagai uang sungguhan.
