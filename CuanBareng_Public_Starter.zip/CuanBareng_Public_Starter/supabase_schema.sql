-- CuanBareng database starter for Supabase (not connected to the demo frontend yet)
-- Review and run only in your own Supabase project's SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 80),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 100),
  category text not null check (category in ('Gadget','Rumah','Fashion','Lainnya')),
  price_idr bigint check (price_idr is null or price_idr >= 0),
  affiliate_url text not null check (affiliate_url like 'https://%'),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;

-- Each user can read and change only their own profile.
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Product links are private to their owner by default. Public catalog sharing
-- should be implemented with a reviewed publishing/visibility design before launch.
create policy "products_select_own" on public.products
  for select to authenticated using (auth.uid() = owner_id);
create policy "products_insert_own" on public.products
  for insert to authenticated with check (auth.uid() = owner_id);
create policy "products_update_own" on public.products
  for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "products_delete_own" on public.products
  for delete to authenticated using (auth.uid() = owner_id);

-- Never place a Supabase service_role key in a browser app or APK.
-- Use only the anon/publishable key in a client after RLS is enabled.
